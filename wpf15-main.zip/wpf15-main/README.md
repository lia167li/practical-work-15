



Practic_15

Практическая работа №15

Выполнили Добжинский Андрей и Иван Зотов

Консоль:

![image](https://github.com/user-attachments/assets/469f6143-cf55-4468-a1c5-aa1c7bc2025b)
